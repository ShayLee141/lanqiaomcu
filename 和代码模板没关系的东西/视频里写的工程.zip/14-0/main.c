#include <STC15F2K60S2.H>
#include <intrins.h>

#include "base.h"
#include "key.h"
#include "uart.h"

#include "iic.h"
#include "onewire.h"

#include "myint.h"

int main(void)
{
	uint8_t screen = 1; //1���¶ȣ�2����ѹ
	uint8_t lock = 0; //0��������1������
	uint8_t blink = 0; //��˸��־ 0��1
	uint16_t volt = 0; //��ǰ��λ����ѹ
	uint8_t str_temp[20] = { "TEMP:27.5��" };
	uint8_t str_volt[20] = { "Voltage:1.35V"};
	
	P2 = 0x00;
	CHANNLE(4, 0xFF);
	CHANNLE(5, 0x00);
	CHANNLE(6, 0x00);
	CHANNLE(7, 0x00);
	
	Timer1Init();
	UartInit();
	
	EA = 1;

	while(1)
	{
		/* input */
		read_temp();
		adc_read();
		
		if (Timer10ms_cnt >= 10)
		{
			Timer10ms_cnt = 0;
			
			key_pad_scan();
			
			if (key_value == 4 && key_state == 2) //����
			{
				lock = 1;
			}
			else if (key_value == 5 && key_state == 2) //����
			{
				lock = 0;
			}
			else if (key_value == 12 && key_state == 2) //����
			{
				if (screen == 1)
				{
					str_temp[5] = temperature / 100 + '0';
					str_temp[6] = temperature / 10 % 10 + '0';
					str_temp[8] = temperature % 10 + '0';
					SendString(str_temp);
				}
				else if (screen == 2)
				{
					str_volt[8] = volt / 100 + '0';
					str_volt[10] = volt / 10 % 10 + '0';
					str_volt[11] = volt % 10 + '0';
					SendString(str_volt);
				}
			}
		}
		
		/* process */
		if (cmd) //��û���յ�ָ��
		{
			if (!lock) //��ǰ����
			{
				if (cmd & 0x01)
				{
					screen = 1;
					cmd &= ~0x01;
				}
				else if (cmd & 0x02)
				{
					screen = 2;
					cmd &= ~0x02;
				}
			}
			else //��ǰ����
				cmd &= ~0x03;
		}
		
		volt = 5 * ((float)adc_level[3] / 2.55);
		
		if (Timer100ms_cnt >= 100)
		{
			Timer100ms_cnt = 0;
			
			blink = !blink; //!�Ե� ~����
		}
		
		/* output */
		dig = dig_all[screen];
		
		dig_all[1][5] = temperature / 100;
		dig_all[1][6] = temperature / 10 % 10 + 32;
		dig_all[1][7] = temperature % 10;
		
		dig_all[2][5] = volt / 100 + 32;
		dig_all[2][6] = volt / 10 % 10;
		dig_all[2][7] = volt % 10;
		
		if (screen == 1) //�¶�
		{
			led_state |= 0x01; //L1
			led_state &= ~0x02; //L2
		}
		else if (screen == 2) //��ѹ
		{
			led_state &= ~0x01; //L1
			led_state |= 0x02; //L2
		}
		
		if (lock && blink)
			led_state |= 0x04; //L3
		else
			led_state &= ~0x04; //L3
		
		if (temperature >= 280)
			high_power_state |= 0x10;
		else
			high_power_state &= ~0x10;
		
		if (volt > 360)
			high_power_state |= 0x40;
		else
			high_power_state &= ~0x40;
	}
	
//	return 0;
}
