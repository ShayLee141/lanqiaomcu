# lanqiaomcu
github:https://github.com/ShayLee141/lanqiaomcu
自己写的的蓝桥杯单片机代码模板，不是最好的，而是我高度针对比赛过程写的模板
