#ifndef __NE555_H__
#define __NE555_H__

#include <STC15F2K60S2.H>

#include "myint.h"

#endif
