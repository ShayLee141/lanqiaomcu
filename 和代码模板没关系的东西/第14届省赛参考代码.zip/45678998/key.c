#include "key.h"

uint8_t key_value = 0;
uint8_t key_state = 0;

uint8_t key_value_all[2][2] = 
{
	5, 9, 
	4, 8, 
};

void key_scan()
{
	uint8_t c, r;
	
	P32 = P33 = 1;
	P42 = P44 = 0;
	
	if (~P3 & 0x0C) //�а�������
	{
		if (!P32)
			r = 0;
		else if (!P33)
			r = 1;
		
		P32 = P33 = 0;
		P42 = P44 = 1;
		
		if (!P44)
			c = 0;
		else if (!P42)
			c = 1;
		
		key_value = key_value_all[r][c];
		
		if (key_state < 250)
			key_state++;
	}
	else
	{
		if (key_value && key_state <= 250 && key_state >= 200)
		{
			key_state = 255;
		}
		else
		{
			key_value = 0;
			key_state = 0;
		}
	}
}
