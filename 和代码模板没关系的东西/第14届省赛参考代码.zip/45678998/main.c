#include "main.h"

#include "base.h"
#include "key.h"

#include "iic.h"
#include "onewire.h"
#include "ds1302.h"

void Delay750ms()		//@12.000MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 35;
	j = 51;
	k = 182;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void main()
{
	uint8_t mode = 0;
	uint8_t screen = 0;
	uint8_t screen_1 = 0;
	
	int p_temp = 30;
	uint16_t temp_last = 0;
	uint16_t temp_max = 0;
	uint16_t temp_sum = 0;
	
	uint8_t hum = 0;
	uint8_t hum_last = 0;
	uint8_t hum_max = 0;
	uint16_t hum_sum = 0;
	
	uint8_t trigger_flag = 0;
	uint8_t trigger = 0;
	
	uint16_t tem = 0;
	
	bit blink = 0;
	
	P2 = 0x00;
	CHANNLE(5, 0x00);
	CHANNLE(4, 0xFF);
	CHANNLE(6, 0x00);
	CHANNLE(7, 0x00);
	
	read_temp();
	wirte_ds1302();
	
	
	EA = 1;
	
	Delay750ms();
	
	Timer0_Init();
	TimerPCA_Init();

	loop:
	
	if (timer10ms >= 10)
	{
		timer10ms = 0;
		
		read_ds1302();
		read_pcf8591();
		read_temp();
		
		if (mode == 0)
		{
			key_scan();
			
			if (key_value == 4 && key_state == 2)
			{
				if (++screen >= 3)
				{
					screen = 0;
				}
				
				if (screen == 1) //�л�Ϊ���Խ���
					screen_1 = 0; //����Ϊ�¶Ȼ���
			}
			else if (key_value == 5 && key_state == 2)
			{
				if (screen == 1)
				{
					if (++screen_1 >= 3)
					{
						screen_1 = 0;
					}
				}
			}
			else if (key_value == 8 && key_state == 2)
			{
				if (screen == 2)
					if (p_temp < 99)
					{
						p_temp++;
					}
			}
			else if (key_value == 9 && key_state == 2)
			{
				if (screen == 2)
					if (p_temp > 0)
					{
						p_temp--;
					}
			}
			else if (key_value == 9 && key_state == 255)
			{
				trigger = 0;
				temp_max = 0;
				temp_sum = 0;
				hum_max = 0;
				hum_sum = 0;
			}
		}
		
		if (timer100ms >= 100)
		{
			timer100ms = 0;
			
			blink = !blink;
		}
		
		if (ADC_level > 0xC0)
		{
			trigger_flag = 0;
		}
		else if (trigger_flag == 0)
		{
			trigger_flag = 1;
			
			mode = 1;
			timer3s = 0;
			
			/* ʪ�Ȳɼ� */
			if (ne555_out > 200 || ne555_out < 20) //��������
			{
				dig_all[5][3] = 10;
				dig_all[5][4] = 10;
				dig_all[5][6] = 10;
				dig_all[5][7] = 10;
				led_state |= 0x20;
				
//				dig_all[5][3] = ne555_out / 1000;
//				dig_all[5][4] = ne555_out / 100 % 10;
//				dig_all[5][6] = ne555_out / 10 % 10;
//				dig_all[5][7] = ne555_out % 10;
			}
			else
			{
				hum = (ne555_out - 20) * (8.0 / 18.0) + 10;
				led_state &= ~0x20;
				
				trigger++;
				
				hum_sum += hum;
				hum_max = hum > hum_max ? hum : hum_max;
				
				dig_all[5][6] = hum / 10;
				dig_all[5][7] = hum % 10;
				
				/* �¶Ȳɼ� */
				temp_sum += temp;
				temp_max = temp > temp_max ? temp : temp_max;
				
				dig_all[5][3] = temp / 10;
				dig_all[5][4] = temp % 10;
				
				/* ʱ�䱣�� */
				dig_all[3][3] = time[0] / 0x10;
				dig_all[3][4] = time[0] % 0x10;
				
				dig_all[3][6] = time[1] / 0x10;
				dig_all[3][7] = time[1] % 0x10;
				
				if (temp > temp_last && hum > hum_last && trigger >= 2)
					led_state |= 0x10;
				else
					led_state &= ~0x10;
				
				temp_last = temp;
				hum_last = hum;
			}
		}
		
		if (blink && (temp_last > p_temp))
			led_state |= 0x08;
		else
			led_state &= ~0x08;
		
		if (mode)
		{
			if (timer3s >= 3000)
				mode = 0;
		}
		
		/* �����л� */
		led_state &= ~0x07;
		if (mode == 0) //������ģʽ
		{
			switch (screen)
			{
				case 0:
					dig = dig_all[0];
					led_state |= 0x01;
					break;
				
				case 1:
					dig = dig_all[1 + screen_1];
					led_state |= 0x02;
					break;
				
				case 2:
					dig = dig_all[4];
					led_state |= 0x04;
					break;
				
				default:
					screen = 0;
			}
		}
		else //�����ɼ�ģʽ
		{
			dig = dig_all[5];
		}

		/* ʱ����ʾ */
		dig_all[0][0] = time[0] / 0x10;
		dig_all[0][1] = time[0] % 0x10;
		
		dig_all[0][3] = time[1] / 0x10;
		dig_all[0][4] = time[1] % 0x10;
		
		dig_all[0][6] = time[2] / 0x10;
		dig_all[0][7] = time[2] % 0x10;
		
		/* ���� */
		dig_all[3][1] = trigger / 10;
		dig_all[3][2] = trigger % 10;
		
		if (trigger == 0)
		{
			dig_all[1][1] = 16;
			dig_all[1][2] = 16;
			dig_all[1][3] = 16;
			dig_all[1][4] = 16;
			dig_all[1][5] = 16;
			dig_all[1][6] = 16;
			dig_all[1][7] = 16;
			
			dig_all[2][1] = 16;
			dig_all[2][2] = 16;
			dig_all[2][3] = 16;
			dig_all[2][4] = 16;
			dig_all[2][5] = 16;
			dig_all[2][6] = 16;
			dig_all[2][7] = 16;
			
			dig_all[3][3] = 16;
			dig_all[3][4] = 16;
			dig_all[3][5] = 16;
			dig_all[3][6] = 16;
			dig_all[3][7] = 16;
		}
		else
		{
			dig_all[1][2] = temp_max / 10;
			dig_all[1][3] = temp_max % 10;
			dig_all[1][4] = 17;
			tem = (float)temp_sum / (float)trigger * 10.0;
			dig_all[1][5] = tem / 100;
			dig_all[1][6] = tem / 10 % 10 + 32;
			dig_all[1][7] = tem % 10;
			
			dig_all[2][2] = hum_max / 10;
			dig_all[2][3] = hum_max % 10;
			dig_all[2][4] = 17;
			tem = (float)hum_sum / (float)trigger * 10.0;
			dig_all[2][5] = tem / 100;
			dig_all[2][6] = tem / 10 % 10 + 32;
			dig_all[2][7] = tem % 10;
			
			dig_all[3][5] = 17;
		}

		/* ������ʾ */
		dig_all[4][6] = p_temp / 10;
		dig_all[4][7] = p_temp % 10;
	}
	
	goto loop;
}
