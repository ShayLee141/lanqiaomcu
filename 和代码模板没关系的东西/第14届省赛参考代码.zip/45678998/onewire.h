#ifndef __ONEWIRE_H__
#define __ONEWIRE_H__

#include "main.h"

extern uint16_t temp;

void read_temp();

#endif
