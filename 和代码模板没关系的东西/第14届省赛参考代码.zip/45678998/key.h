#ifndef __KEY_H__
#define __KEY_H__

#include "main.h"
#include "base.h"

extern uint8_t key_value;
extern uint8_t key_state;

void key_scan();

#endif
