#ifndef __BASE_H__
#define __BASE_H__

#include "main.h"

#define CHANNLE(n, x) { P0 = x; P2 |= n << 5; P2 &= 0x1F; }

extern uint8_t dig_all[][8];
extern uint8_t *dig;
extern uint8_t led_state;
extern uint8_t timer10ms;
extern uint16_t timer3s;
extern uint8_t timer100ms;

extern uint16_t ne555_out;

void Timer0_Init(void);
void TimerPCA_Init(void);

#endif
