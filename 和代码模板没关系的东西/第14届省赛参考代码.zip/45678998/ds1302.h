#ifndef __DS1302_H__
#define __DS1302_H__

#include "main.h"

extern uint8_t time[3];

void wirte_ds1302(void);
void read_ds1302(void);

#endif
