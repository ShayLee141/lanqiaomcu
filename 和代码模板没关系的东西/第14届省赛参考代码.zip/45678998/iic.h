#ifndef __IIC_H__
#define __IIC_H__

#include "main.h"

extern uint8_t ADC_level;

void read_pcf8591(void);

#endif
